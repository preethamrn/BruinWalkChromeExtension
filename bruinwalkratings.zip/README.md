# BruinWalkChromeExtension

This is Google Chrome extension called "UCLA BruinWalk Ratings - Easy Access"
It adds BruinWalk.com professor ratings to class registration pages in the student UCLA web portal.

Chrome Store page: https://chrome.google.com/webstore/detail/ucla-bruinwalk-ratings-ea/iohhcbccamefhmjnppendeffiapogjfg

Current Version in this Branch: 0.0.5 in progress

